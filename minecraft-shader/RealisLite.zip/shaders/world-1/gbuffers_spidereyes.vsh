#version 330 compatibility
// RealisLite - gbuffers_spidereyes.vsh (automatisch erzeugt von tools/gen_wrappers.py)
#define DIM_NETHER
#define PROGRAM_TEXTURED
#define PROGRAM_EMISSIVE
#include "/program/gbuffers_lit.vsh"
