#version 330 compatibility
// RealisLite - gbuffers_skytextured.fsh (automatisch erzeugt von tools/gen_wrappers.py)
#define DIM_END
#include "/program/gbuffers_skytextured.fsh"
